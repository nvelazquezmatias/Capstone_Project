

OVERVIEW

Thank youu for purchasing this Button Asset Pack! This pack includes a variety of pixel-art buttons that you can use in your games and applications. The buttons are provided in a single sprite sheets for efficient use.

BUTTON DETAILS

The sprite sheets contain the following buttons: 

PLAY
START
MENU
RESUME
RESTART
YES
NO
QUIT
NEXT
BACK
SHOP
PAUSE
LOGIN
OPTIONS
LEVELS
NEW LEVEL
NEW GAME
GAME OVER

PLAY ICON
STOP ICON
MENU ICON
MUSIC ON ICON
MUSIC OFF ICON
NO ICON
MINUS ICON
PLUS ICON
AROWS ICONS
etc.

I made 2 versions of buttons. One are with hard black edges and the other is without. Now there are only 3 color options but I will make more soon. 




LICENSE

This asset pack is licensed for personal and commercial use. You may use these assets in your projects, but you may not redistribute or resell them as is.

Contact

If you have any questions or requests what buttons should I add next, please leave me a comment under the asset pack! I will be happy to create more versions if needed.

